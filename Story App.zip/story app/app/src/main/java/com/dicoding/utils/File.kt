package com.dicoding.utils

class File {
}